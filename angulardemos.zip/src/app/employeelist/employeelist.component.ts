import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employeelist',
  templateUrl: './employeelist.component.html',
  styleUrls: ['./employeelist.component.css']
})
export class EmployeelistComponent implements OnInit {

  constructor() { }

employee:any[] = [
  {
    code: "717" ,name:'Niharika' ,gender:'female', annualSalary: 25000 ,
    dateOfBirth:'06/28/1996'
  },
  {
    code: "718" ,name:'Mayur' ,gender:'male', annualSalary: 20000 ,
    dateOfBirth:'06/26/1994'
  },
  {
    code: "719" ,name:'Siddhartha' ,gender:'male', annualSalary: 80000 ,
    dateOfBirth:'11/27/1997'
  }

] ;

  ngOnInit() {
  }

}
