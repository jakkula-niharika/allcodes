import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'empgender'
})
export class EmpgenderPipe implements PipeTransform {

  transform(gender: string): string {
    if(gender.toLowerCase()=="male")
    return "Mr."+ gender;
    else
    return "Ms."+ gender;

    
  }

}
