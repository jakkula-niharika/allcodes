import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ProductService } from '../Service/product.service';
import { Product } from '../model/product';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  products: Product[] = [];


  constructor(private prodservice: ProductService) { }

  ngOnInit() {
    this.products = this.prodservice.getProducts();
  }

  deleteFromService(product: Product) {
    this.prodservice.deleteproduct(product);
  }

  addproductToService(id, productname, cost, category){
    this.prodservice.addProducts(id, productname, cost, category);
  }
  updateToService(id,name,cost,category){

    this.prodservice.updateProduct(id,name,cost,category)
  
  }
  @ViewChild('refproductid') prodidInput :ElementRef;
  @ViewChild('refproductname') prodnameInput :ElementRef;
  @ViewChild('refproductcost') prodcostInput :ElementRef;
  @ViewChild('refproductcategory') prodcategoryInput :ElementRef;
clearTextboxes(){
  this.prodidInput.nativeElement.value ='';
  this.prodnameInput.nativeElement.value ='';
  this.prodcostInput.nativeElement.value ='';
  this.prodcategoryInput.nativeElement.value ='';
}
}
