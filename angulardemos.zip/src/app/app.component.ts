import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
 
  firstName : string= "Jakkula" ;
  lastName: string = "Niharika" ;
  address: string = "Bangalore" ;
  salary: number = 25000;

}
