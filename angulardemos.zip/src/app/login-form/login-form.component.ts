import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, Validators, FormControl } from '@angular/forms';


@Component({
  selector: 'app-login-form',
  templateUrl: './login-form.component.html',
  styleUrls: ['./login-form.component.css']
})
export class LoginFormComponent implements OnInit {
  loginForm: FormGroup;

  submitted: boolean = false;
  
  invalidLogin: boolean = false;
  
  constructor(private router:Router) { }
eId={
  email:"",
  password:""
}
 
  OnClick(abc) {
    console.log(abc.value);
this.eId=abc.value
if(this.eId.email=="ni@gmail.com" && this.eId.password=="123456"){
  this.router.navigate(['employeelist']);
}
   
  }
ngOnInit() {
  this.loginForm = new FormGroup({
    email:new FormControl('', [Validators.required]),
    password:new FormControl('', [Validators.required])
    }); 
    }   
}



