import { Component, OnInit } from '@angular/core';
import { Product } from '../model/product';

@Component({
  selector: 'app-assignment',
  templateUrl: './assignment.component.html',
  styleUrls: ['./assignment.component.css']
})
export class AssignmentComponent implements OnInit {

  constructor() { }
  subjects: string[] = ["Angular", "MongoDB", "Express"]

  showFaculty: boolean = true;
  Faculty: string = "Rashmi Pawaskar";

  Duration: number = 30;
  
  isValid: boolean= false;




  //object
  pro: Product = {
    id: 11,
    name: "Note 8",
    cost: 20000,
    category: "Electronics"
  };
  //array
  products: Product[] = [
    { id: 12, name: "redmi not4", cost: 18000, category: "Electronics" },
    { id: 13, name: "redmi not5", cost: 19000, category: "Electronics" },
    { id: 14, name: "redmi not6", cost: 20000, category: "Electronics" }
  ];




  ngOnInit() {
  }

}
