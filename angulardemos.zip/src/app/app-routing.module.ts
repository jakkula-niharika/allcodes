import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AboutComponent } from './about/about.component';
import { HomeComponent } from './home/home.component';
import { ContactComponent } from './contact/contact.component';
import { EmployeelistComponent } from './employeelist/employeelist.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { EventComponent } from './event/event.component';
import { TemplateDrivenFormComponent } from './template-driven-form/template-driven-form.component';
import { ReactiveFormComponent } from './reactive-form/reactive-form.component';
import { RegisterFormComponent } from './register-form/register-form.component';
import { LoginFormComponent } from './login-form/login-form.component';
import { ProductComponent } from './product/product.component';
import { AuthGuard } from './guards/auth.guard';
import { ParentComponent } from './parent/parent.component';


const routes: Routes = [
  { path: '', component: HomeComponent},
  { path: 'about', component: AboutComponent ,canActivate:[AuthGuard]},
  { path: 'contact', component: ContactComponent,canDeactivate:[AuthGuard] },
  { path: 'employeelist', component: EmployeelistComponent,canActivate:[AuthGuard]},
  {path:'event', component:EventComponent,canDeactivate:[AuthGuard]},
  {path:'templatedrivenform', component:TemplateDrivenFormComponent},
  {path:'reactiveform', component:ReactiveFormComponent},
  {path:'loginform', component:LoginFormComponent},
  {path:'registerform', component:RegisterFormComponent},
  {path:'servicedemo', component:ProductComponent},
  {path: 'parenttochild', component: ParentComponent},
  {path:'**', component:PageNotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
