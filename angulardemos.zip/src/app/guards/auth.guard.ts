import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, CanActivate, Router } 
from '@angular/router';
import { Observable } from 'rxjs';
import { ContactComponent } from '../contact/contact.component';


@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements  CanActivate{
  canActivate(_next: ActivatedRouteSnapshot, 
              _state: RouterStateSnapshot): boolean | UrlTree | 
              Observable<boolean | UrlTree> | Promise<boolean | UrlTree> {

                alert('Unauthorized access, redirect to login page');
                this.router.navigate(['loginform']);
    return true;
  }
  constructor(private router:Router){
  }
canDeactivate(component:ContactComponent): boolean{
return window.confirm('Are you sure you want to navigate?');
}
}
