import { Injectable } from '@angular/core';
import { Product } from '../model/product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  products: Product[] = [
    { id: 1, name: 'laptop', cost: 1000, category: 'electronics' },
    { id: 2, name: 'phone', cost: 2500, category: 'electronics' },
    { id: 3, name: 'fan', cost: 4500, category: 'electronics' },
  ];
  getProducts() {
    return this.products;
  }
  addProducts(_id: number, productname: string, cost: number, category: string) {
    let newproduct = {
      id: this.products.length+1,
      name: productname,
      cost: cost,
      category: category
    };
    return this.products.push(newproduct);
  }
  deleteproduct(product: Product) {
    let indexposition = this.products.indexOf(product);
    return this.products.splice(indexposition, 1);
    
  }
  updateProduct(ids,names,costs,categorys){

    let searchId=ids
    
    for(let prods of this.products){
    
      if(prods.id==searchId){
    
        prods.id=ids;
    
        prods.name=names;
    
        prods.cost=costs;
    
        prods.category=categorys;
      }
    
    }
    
    return this.products
    
    }
  constructor() { }
}
