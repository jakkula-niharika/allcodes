import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-event',
  templateUrl: './event.component.html',
  styleUrls: ['./event.component.css']
})
export class EventComponent implements OnInit {

  constructor() { }
  names: any[] = ["Siddhartha", "Niharika", "Sumanth", "Abhiram"];
  ngOnInit() {
  }
  ClickMe() {
    alert("Hello Form click me.....!");
  }
  DeleteProduct(id: number) {
    alert("Product to be  deleted: " + id);
  }
  EditProduct(id: number, name: string) {
    alert(`Product to be Edited ${id} and ${name}`);
  }

  //adding a name into an array that is entered in the text box
  addName(name: string) {
    alert(name);
    this.names.push(name);
  }

  //deleting an element from the array by clicking on the cross button
  deleteName(name: string) {
    alert(name);
    let indexPosition = this.names.indexOf(name);
    this.names.splice(indexPosition,1);
  }

}
